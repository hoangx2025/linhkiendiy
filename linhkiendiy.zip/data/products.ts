import { Product } from "./product";

import { boostBuckXl6009Lm2577 } from "./productList/boostBuckXl6009Lm2577";
import { lm2596CcCv } from "./productList/lm2596CcCv";
import { hcSr501 } from "./productList/hcSr501";
import { lightSensorLm393 } from "./productList/lightSensorLm393";
import { irfz44nMossfet } from "./productList/irfz44nMossfet";
import { mt3608Booster } from "./productList/mt3608Booster";
import { mpu6500Sensor } from "./productList/mpu6500Sensor";
import { tp4056TypeCProtected } from "./productList/tp4056TypeCProtected";
import { xl4015 } from "./productList/xl4015";
import { hlkLd2410C } from "./productList/hlkLd2410C";
import { max30102Sensor } from "./productList/max30102Sensor";
 


export const products: Product[] = [
  boostBuckXl6009Lm2577,
  xl4015,
  lm2596CcCv,
  hcSr501,
  lightSensorLm393,
  irfz44nMossfet,
  mt3608Booster,
  mpu6500Sensor,
  tp4056TypeCProtected,
  hlkLd2410C,
  max30102Sensor
];

// export function getProductById(id: string) {
//   return products.find((p) => p.id === id);
// }

export function getProductById(id: string): Product | undefined {
  return products.find(p => p.id === id);
}