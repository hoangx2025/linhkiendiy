export const siteConfig = {
  showPrice: false, // ← đổi true / false ở đây

  contact: {
    phone: "+84901234567",
    email: "contact@shopdiy.vn",
  }
};
